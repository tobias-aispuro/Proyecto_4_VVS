# Reporte de errores identificados — Login

**Fecha de ejecución:** 2026-10-05T21:50:13.536Z

## Resumen

- **Casos ejecutados:** 13
- **Pasaron:** 12
- **Fallaron:** 1
- **No ejecutados:** 0

## Resultado por caso

| ID | Caso | Resultado |
| --- | --- | --- |
| LOG-01 | LOG-01 - Login con correo "" y contraseña "" | pasó |
| LOG-02 | LOG-02 - Login con correo "" y contraseña "hermione2025" | pasó |
| LOG-03 | LOG-03 - Login con correo "" y contraseña "123" | pasó |
| LOG-04 | LOG-04 - Login con correo "ron@hogwarts.com" y contraseña "" | pasó |
| LOG-05 | LOG-05 - Login exitoso con correo "ron@hogwarts.com" y contraseña "hermione2025" | pasó |
| LOG-06 | LOG-06 - Login con correo "ron@hogwarts.com" y contraseña "123" | pasó |
| LOG-07 | LOG-07 - Login con correo "vyvs@mail.com" y contraseña "" | pasó |
| LOG-08 | LOG-08 - Login con correo "vyvs@mail.com" y contraseña "hermione2025" | pasó |
| LOG-09 | LOG-09 - Login con correo "vyvs@mail.com" y contraseña "123" | pasó |
| LOG-10 | LOG-10 - Login con correo "harry.com" y contraseña "" | pasó |
| LOG-11 | LOG-11 - Login con correo "harry.com" y contraseña "hermione2025" | pasó |
| LOG-12 | LOG-12 - Login con correo "harry.com" y contraseña "123" | pasó |
| LOG-13 | LOG-13 - Bloqueo tras 3 intentos fallidos con correo "ron@hogwarts.com" | fallido |

## Errores identificados

### LOG-13 — LOG-13 - Bloqueo tras 3 intentos fallidos con correo "ron@hogwarts.com"

- **Paso que no se cumplió:** debería ver la advertencia "Atención, su cuenta está a punto de ser bloqueada."
- **Resultado esperado:** Atención, su cuenta está a punto de ser bloqueada.
- **Resultado observado:** El sistema dejó vacío el mensaje esperado.

